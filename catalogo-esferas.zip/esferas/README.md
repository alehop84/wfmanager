# Catálogo de esferas (Zepp OS 3.0)

1. `zeus create` -> plantilla vacía (API 3.0), elige tus dispositivos.
2. Copia `page/index.js`, `page/detail.js` y `data/catalog.js` a tu proyecto.
3. En `app.json` (targets.default.module.page.pages): ["page/index", "page/detail"].
4. Pon las miniaturas (thumb_1.png...) en `assets/` (o assets/<plataforma>/).
5. Edita `data/catalog.js` y prueba con `zeus preview`.
